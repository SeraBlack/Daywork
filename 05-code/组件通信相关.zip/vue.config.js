module.exports = {
	lintOnSave: false
}