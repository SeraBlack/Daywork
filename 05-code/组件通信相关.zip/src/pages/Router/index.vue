<template>
  <div>
    Router
  </div>
</template>

<script type="text/ecmascript-6">

  export default {
    name: 'Router',
  }
</script>