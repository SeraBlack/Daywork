<template>
  <div>
    <!-- <button @click="add">添加一个响应式的数据</button>
   <p>{{obj.msg}}</p>
   <p>{{msg2}}</p>
   <hr/>
   <p>{{obj2.name}}</p>
   <hr/>
   <DataTest :msg3="msg3" :obj2="obj2" /> -->
   <h2>父级组件中的内容</h2>
    <p>{{ msg1 }}</p>
    <p>{{ obj.name }}</p>
    <p>{{obj.age}}</p>
    <hr />
    <h2>子级组件中的内容</h2>
    <DataTest :msg1="msg1" :obj="obj" />

    <hr>
    <h2>响应式的数据操作</h2>
    <p>{{msg2}}</p>
    <button @click="add">添加一个响应式的数据</button>
    <button @click="updateMsg2">修改一个数据</button>
  </div>
</template>

<script type="text/ecmascript-6">
/*
  1. 通过this.$data添加响应式数据,是不行的
  2. 在data中,return外部定义数据,也是非响应式的数据,
  3. 更新响应式数据,非响应式数据是否会变化(页面会不会更新)
  4. 子级组件是否可以直接更新父级组件的数据(基本类型的数据不可以,引用类型的数据是可以的)
  5. 在data中,return外部定义一个数组,该数组也是非响应式的数组数据

*/
import DataTest from './DataTest'
export default {
  name: 'Reactive',

  data() {
    this.msg2='真好啊'
    this.arr=[]
    return {
      msg1: '渊哥',
      obj:{
        name:'小强强'
      }
    }
    // this.msg2 ='第二个数据'
    // return {
    //  obj:{},
    //  msg3:'第三个数据',
    //  obj2:{
    //    name:'小明'
    //  }
    // }
  },

  methods: {
    add() {

      // 新的内容
      // 这种写法是不能直接添加响应式数据的
      // this.$set(this.$data,'msg2','渊哥好帅哦')

      // this.$set(this.$data,'msg2','渊哥好帅哦')

      // 这里不行,不能直接添加
      // this.$set(this.$data,'msg','真好')
      // 这个可以的
      // this.$set(this.obj,'msg','真好')
      // 如果更新响应式数据,非响应式数据变化了,页面会不会更新
      // 这个不是响应式数据
      // this.obj.msg = '真好'
      // 这个界面不会变化
      // this.msg2 ='可以吗?'
      // 响应式的数据变化了,页面会更新,因为非响应式的数据也变化了,随着界面更新,也会更新
      // this.$set(this.obj,'msg','真好')
      // this.msg2 ='可以吗?'

      // 不是响应式的,
      // this.obj.age= 10
      // this.$set(this.obj,'age',100)
    },
    updateMsg2(){
      // 通过this.$set方法可以为当前的响应式对象,添加响应式的属性数据
      // 但是不能为当前组件中直接添加响应式的数据
      // 不是响应式的数据,即使修改,页面也不会重新渲染
      // this.msg2 = '强哥好帅'
      // 如果我改变了一个响应式的数据,同时也改变了非响应式的数据,页面渲染的时候,非响应式的数据所对应的页面有没有重新的渲染,有重新渲染,不是非响应式数据来改变的

      // 响应式数据变化了,页面才会重新渲染
      this.obj.name = '远哥'
      // 非响应式的数据也变化了

      this.msg2 = '强哥哥'

    }
  },

  components: {
    DataTest,
  },
}
</script>