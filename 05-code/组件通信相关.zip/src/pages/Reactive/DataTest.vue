<template>
  <div>
   <!-- <p>{{msg3}}</p>
   <button @click="updateMsg3">更新父级组件传递过来的数据</button> -->

   <p>{{msg1}}</p>
   <p>{{obj.name}}</p>
   <button @click="updateMsg1">修改父级组件传递过来的数据</button>
  </div>
</template>

<script>
export default {
  name: 'DataTest',
  // props: ['msg3','obj2'], // 是
  props:['msg1','obj'],
  data () {
   
    return {
     
    }
  },

 

  methods: {

    updateMsg1(){
      // 点击子级组件的按钮,修改父级组件传递过来的数据
      // this.msg1 = '渊哥好帅'
      this.obj.name ='小甜甜'
    }
  //  updateMsg3(){
  //    // 不能直接更新父级组件传递过来的基本类型的数据
  //    // this.msg3 = '更新父级组件的数据'
  //    // 如果父级组件传递过来的是对象,那么子级组件可以直接更新
  //    // this.obj2.name="小强强"
  //  }
  },
}
</script>
