export function sum (x, y) {
  return x + y
}

export default function sum2 (x, y) {
  return x + y + 1
}