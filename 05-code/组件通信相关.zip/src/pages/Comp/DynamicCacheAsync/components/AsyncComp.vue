<template>
  <div>AsyncComp</div>
</template>

<script>
export default {
  name: 'AsyncComp',
}
</script>
