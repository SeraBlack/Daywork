<template>
  <div>
    Posts Component
  </div>
</template>