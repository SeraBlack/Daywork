<template>
  <div>
    Home Component
  </div>
</template>
