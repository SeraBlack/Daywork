<template>
  <div>
    <h2 ref="msg1">msg:{{msg}}</h2>
    <h2 ref="msg2">msg2:{{msg2}}</h2>
    <button @click="test">测试</button>
  </div>
</template>
<script>
export default {
  name: 'NextTick',
  data() {
    return {
      msg: 'abc',
      msg2: '12345'
    }
  },
  methods: {
    test() {
      // 如:
      this.msg2 = 'd' // 修改了数据
      // 在下次 DOM 更新循环结束之后执行延迟回调。在修改数据之后立即使用这个方法，获取更新后的 DOM
      this.$nextTick(() => {
        console.log(1, this.msg, this.$refs.msg1.innerHTML) // 1 b abc
      })
      this.msg = 'b' // 修改了数据
      this.$nextTick(() => {
        console.log(2, this.$refs.msg1.innerHTML) // 2 b
      })
    }
  }
}
// 在下次 DOM 更新循环结束之后执行延迟回调。在修改数据之后立即使用这个方法，获取更新后的 DOM。
// nextTick中的方法执行的时机是在DOM更新之前,此时里面的回调应该是微任务,可能是通过Promise或者MutationObserver来控制的
// nextTick方法中应该有专门存储回调的数组
// nextTick方法中的两个回调执行的时机应该在DOM更新后,应该是宏任务,可能是通过定时器来控制的
// nextTick方法中除了我们传入的回调,猜测内部还有可能有更新界面的回调函数














// nextTick方法中应该有Promise/MutationObserver
// nextTick方法中应该有定时器
// nextTick方法中应该有数组 存储 传入进来的回调的
// nextTick方法中的回调,执行的比较好的时机,应该是所有的数据都改变了,然后页面渲染一次后 再执行

// 虽然数据更新两次,但是页面应该渲染一次
// nextTick方法中应该有个数组,用来存储回调函数---存储了2个(有可能都是微任务,都是宏任务,一个宏,一个微任务)

// 将回调延迟到下次 DOM 更新循环之后执行。在修改数据之后立即使用它，然后等待 DOM 更新。

// 分析:
// 如果是先执行nextTick方法中的回调,那么结果应该是1,abc,abc,如果是后执行nextTick方法中的回调,结果1,b,b
// 如果nextTick方法中的回调是微任务,应该先执行this.msg='b'初始化同步代码,然后执行微任务,结果:1,b,abc,最后渲染界面
// 如果nextTick方法中的回调是宏任务,那么应该先执行this.msg='b',然后渲染界面,之后执行回调,结果:1,b,b

// 结果,依赖结果,指明分析的结果

// 最终的执行结果是:nextTick方法中的回调此时是个微任务,执行了初始化的同步代码,然后修改了data中的msg属性值,此时执行了回调函数,结果:1,b,由于此时的是回调是微任务,所以,this.$refs.msg1.innerHTML结果仍然是:abc,然后才渲染就界面,界面渲染完毕后,再获取h2中间的内容才能够是:b

// 如何设置一个回调是微任务,如何设置一个回调是宏任务?
// 设置回调为微任务,可以使用Promise/MutationObserver--h5中新增的,设置一个回调为宏任务,可以使用定时器
// 官方文档的内容:
// 将回调延迟到下次 DOM 更新循环之后执行。在修改数据之后立即使用它，然后等待 DOM 更新。
// 得到的结果:
// nextTick方法使用的时机,应该是某个数据修改之后再使用,内部的回调函数才会延迟到DOM更新之后再执行,最后DOM更新后就可以看到效果了

// 结论: $nextTick方法,尽可能的放在修改数据之后再使用.

// 分析及通过结果得到的结果:---通过分析和执行结果的到结论
// 先修改了一次数据,然后执行nextTick方法,又更改了一次数据,又执行了一次nextTick方法
// 一共修改了两次数据,那么界面不需要更新2次,因为效率低,所以,修改了两次数据，再执行nextTick方法的时候,内部应该有一个容器,先把nextTick方法中的回调存储起来,两次修改数据,DOM渲染只有一次,容器中存储了两个nextTick的回调,最终再调用这两个回调,得到其结果

// 验证我的分析,不想通过代码的结果来验证,查看nextTick的源码:
// 源码中: 内部有一个callbacks数组,用来存储传入nextTick方法中的所有的回调
// 内部有一个flushCallbacks函数,作用执行callbacks数组中的所有回调
// 内部还有Promise和MutationObserver和setTimeout定时器,用来控制callbacks数组中每个回调是微任务还是宏任务

// 源码中有一个queue的数组,用来存储的是watcher对象的
// flushSchedulerQueue函数内部是遍历queue数组,用来执行内部的watcher对象的run方法---用来更新界面的
// 源码中有一个queueWatcher方法,内部调用了nextTick方法,并且传入了flushSchedulerQueue函数
// nextTick方法中不仅有程序员调用的时候传入的回调函数,还有用来更新DOM的watcher对象相关的方法了
// nextTick方法中有两种回调函数,一种是咱们传的,一种是更新界面的
//  nextTick([回调1,回调2,回调3])
// 回调1是微任务,回调2是宏任务,回调3是宏任务
// 尽可能的然更新界面之前的任务都是微任务,更新界面 之后的操作尽可能是宏任务

// 总结:首先,应该在数据更新之后再使用nextTick方法,执行流程:就是先更新数据,然后执行DOM的渲染,最后执行nextTick中的回调函数--推荐
// 如果是先调用nextTick方法,后更新数据,那么是先执行更新数据的代码,然后更新DOM操作,最终调用nextTick中的回调---执行不会报错,但是结果可能不是我们想要的

// 如果是先执行了nextTick中的回调,那么结果应该是1,abc,abc---不成立--此时这个回调执行的时机不在这
// 如果是先修改了msg的值为b,又更新了DOM(更新了界面),那么再执行nextTick中的回调,那么结果应该是:1,b,b---不成立,此时这个回调执行的时机也不在这
// 结果是1 b abc ,那么就说明此时这个回调执行的时机是在 msg值修改后,界面更新之前---此时执行的时机是在DOM更新前
// nextTick中的回调是一个任务,任务就分为微任务和宏任务,
// 微任务在DOM更新前执行,宏任务在DOM更新后执行
// nextTick中的回调(刚刚测试的这个回调)说明是一个微任务,而不是宏任务,为什么?
// 官方说法:在下次 DOM 更新循环结束之后执行延迟回调。在修改数据之后立即使用这个方法，获取更新后的 DOM。
// 说明官方说法有问题?没有问题,原因:那是因为,我使用nextTick方法的方式不对,我是在数据更新之前使用的,造成了nextTick中回调成了一个微任务

// 此时如果先更新一次数据,然后立刻使用nextTick方法,之后立刻再次更新数据,通过分析:
// 应该是更新两次数据,界面只更新一次,所以,nextTick中的回调就执行一次
// 分析: 如果第一次更新数据,该数据的dep会通知对应的watcher,进行DOM的更新,DOM更新后,执行nextTick中的回调,得到的结果DOM更新后的数据,没问题,此时说明这个回调应该是一个宏任务,宏任务在DOM更新后执行
// 又一次更新数据,这个数据的dep也会通知对应的watcher进行DOM更新,
// 两次数据更新,涉及到两次DOM更新,效果很低,更好方式是:两次数据的更新,一次DOM的渲染,再执行nextTick中的回调,更加有意义,那么就说明watcher对象中更新DOM的操作的回调此时应该是属于微任务,nextTick方法中的回调是属于宏任务
// nextTick方法中的回调有的时候是微任务,有的时候是宏任务.
// 如果是你,你怎么控制nextTick方法中的回调是微任务还是宏任务?
// 产生promise的是微任务,使用setTimeout的产生的是宏任务,或者也可以使用h5中新增的MutationObserver产生微任务
// nextTick方法多次调用,多个回调,如何调用,应该是内部有专门存储回调的数组

// 通过源码查看:
// nextTick方法中有callback数组,用来存储传入进去的回调函数
// nextTick方法中确实有Promise的创建/setTimeout的调用/MutationObserver的创建---这些决定了nextTick方法中的回调有可能是微任务也有可能是宏任务
// flushCallbacks函数的调用,会把callbacks数组中的回调函数进行遍历执行
// nextTick方法在源码中的另一个地方也被调用了
// queue是个数组,用来存储watcher对象的
// flushSchedulerQueue函数在遍历quequ, 这个函数被放在了nextTick方法中
// nextTick方法中的回调,有可能是程序员调用的时候传入的回调,也有可能是DOM更新的时候系统调用,传入了watcher所在的回调
// nextTick方法中的回调:用户传入的回调,系统传入的watcher相关的回调(queue中是watcher,flushSchedulerQueue遍历queue中的回调)
// nextTick方法中的callbacks数组中就有用户传入的回调和watcher对象更新DOM的回调
// 更新DOM的回调(watcher的)和用户传入的回调,如何调用,通过系统内部的promise/setTimeout/MutationObserver决定是微任务还是宏任务
// 情况:先执行nextTick后更新数据,那么用户传入的回调是微任务,更新DOM回调是宏任务,否则反过来

// export default {
//   name: 'NextTick',
//   data() {
//     return {
//       msg: 'abc',
//       msg2: '12345'
//     }
//   },
//   methods: {
//     test() {
//       // 先更新数据
//       // this.msg+='==='
//       // 发现,不能立刻获取更新后的DOM
//       // console.log(this.$refs.msg.innerHTML)
//       // 需要等到DOM更新后,再读取更新后的DOM
//       // this.$nextTick(()=>{ // 异步回调==>在DOM异步更新后
//       //   // 此时,为什么先获取了更新的DOM,页面中还没完成DOM更新
//       //   // 因为界面更新是在微任务之后
//       //   alert(this.$refs.msg.innerHTML)
//       // })

//       // 将回调延迟到下次 DOM 更新循环之后执行。在修改数据之后立即使用它，然后等待 DOM 更新。
//       // 下面的代码验证的结果就是:$nextTick方法必须在数据更新后,在数据更新前无效
//       // this.$nextTick(() => {
//       //   alert(this.$refs.msg.innerHTML)
//       // })
//       // this.msg+='===='
//       // alert('数据更新后')

//       // 理解tick
//       // this.msg += '====' // 这个数据更新,后面更新DOM的回调是一个异步任务
//       // this.$nextTick(() => { // 这里的这个回调也是一个异步任务
//       //   alert(this.$refs.msg.innerHTML)
//       // })
//       // 两个回调(更新DOM的异步回调与nextTick指定的回调) 会放在一个大的异步任务中处理的
//       // 源码vue->src->core->util->next-tick中
//       // 内部有一个callbacks用来存储在一个事件回调中的nextTick指令的回调和更新DOM的回调(内部维护的异步任务队列)
//       // 源码vue->src->core->observer->scheduler.js中
//       // 内部有一个queue用来存储在一个事件回调中用于更新DOM的watcher,那DOM更新的任务是一个整体的
//       // 一旦更新了一个数据,会立即将更新DOM的异步任务通过nextTick放入callbacks中
//       // callbacks:[watchers,nextTick1,nextTick2]
//       // 如:
//       this.msg2 = 'd'
//       // 在下次 DOM 更新循环结束之后执行延迟回调。在修改数据之后立即使用这个方法，获取更新后的 DOM。
//       this.$nextTick(() => {
//         // 1 this.msg---msg属性值的结果  this.$refs.msg.innerHTML---DOM中的内容
//         console.log(1, this.msg, this.$refs.msg.innerHTML)
//       })
//       // 后修改的数据
//       this.msg = 'b'
//       this.$nextTick(() => {
//         console.log(2, this.$refs.msg.innerHTML)
//       })

//       // nextTick中用的是哪个异步技术
//       // 简单说:优先使用微任务=>宏任务
//       // 详细说:promise=>MutationObserver=>setImmediate=>setTimeout
//     }
//   }
// }

/*
  前提: 当我们同步更新完数据后,DOM并不会立即更新,DOM是异步更新的
  问题:当更新完数据后,不能立即得到更新后额DOM,解决:使用nextTikck,该方法必须在数据更新后调用

 什么是Tick:
  取出队列中的一个回调任务到调用栈中执行就是一个tick
  一个事件回调是一个Tick
  一个事件回调后的所有更新DOM操作也是一个Tick
  每次调用nextTick都是将回调函数作为一个异步任务放入到任务队列中,也就是作为下一个tick
  内部用一个数组callbacks存储
  包含一个所有DOM更新的watcher数组:watchers ()=>{[watcher,watcher]}
  所有nextTick的回调
  如果第一个是更新数据,callbacks的结构是:[watchers,nextTick1,nextTick2]
  如果第一个是nextTick,[nextTick1,watchers,nextTick2]
  nextTick中用的是哪个异步技术呢?
  简单说:优先使用微任务==>宏任务
  详细说:promise=>MutationObserver=>setImmediate=>setTimeout
 */

// 测试1
// 下面的情况,可以得出结论:第一个nextTick中得到的是DOM更新前的标签中的数据
// 1.此时获取的是页面DOM更新前的数据
// this.$nextTick(() => {
//   console.log(1, this.$refs.msg.innerHTML)
// })
// this.msg = 'b'   // 1. 更新数据
// this.$nextTick(() => {
// 3.得到了更新后的数据
//   console.log(2, this.$refs.msg.innerHTML)
// })
// 在下次 DOM 更新循环结束之后执行延迟回调。在修改数据之后立即使用这个方法，获取更新后的 DOM。
// 解读文档中的内容:必须先更新数据,立刻使用nextTick,回调中的代码执行,才能得到DOM更新后的数据

// 继续测试2
// this.$nextTick(() => {
// 此时可以看出,this.msg确实可以得到更新后的数据,但是DOM没有更新
//   console.log(1, this.msg, this.$refs.msg.innerHTML)
// })
// this.msg = 'b'
// this.$nextTick(() => {
//   console.log(2, this.$refs.msg.innerHTML)
// })
// 得出结论:数据更新,不代表DOM更新,因为DOM更新是一个异步操作

// 测试3
// this.msg2 = 'd'  // 1.先更新msg2
// this.$nextTick(() => {
//   console.log(1, this.msg, this.$refs.msg.innerHTML) // 4. 这里也可以获取更新后的数据及更新后的DOM
// })
// this.msg = 'b' // 2. 再更新msg
// this.$nextTick(() => {
//   console.log(2, this.$refs.msg.innerHTML) // 3.这里一定更新
// })

// 页面中有数据更新---导致dom重新渲染,如果需要在dom渲染更新完毕后有一些操作(文本框创建立刻获取焦点),此时会用到nextTick方法

// 数据更新-----DOM更新
// callbacks中要存储传入进来的回调和更新dom相关的watcher的回调

// queue 数组 存储的是watcher对象   queueWatcher方法用来添加watcher

// flushSchedulerQueue函数中在遍历queue数组,遍历里面的每个watcher,watcher调用run---更新dom操作--回调

// nextTick(flushSchedulerQueue) 更新DOM的操作的watcher相关的方法也添加到了nextTick方法中的callbacks数组中

// nextTick方法中使用callbacks数组添加传进来的每个回调

// flushCallbacks方法内部在遍历nextTick方法中的回调的数组---遍历callbacks数组

// nextTick中有 MutationObserver/Promise/setTimeout
</script>
<style scoped>
</style>